"""
Data module configuration.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class ComfyUISettings:
    """ComfyUI configuration."""

    host: str = "localhost:8188"
    timeout: int = 300  # 5 minutes
    output_dir: str = "./data/synthetic"

    # Generation settings
    default_width: int = 1024
    default_height: int = 1024
    default_steps: int = 20
    default_cfg: float = 7.0
    default_sampler: str = "euler_ancestral"


@dataclass
class DataDiscoverySettings:
    """Data discovery configuration."""

    # Roboflow settings
    roboflow_api_key: str = ""
    roboflow_workspace: str = ""

    # Kaggle settings
    kaggle_username: str = ""
    kaggle_key: str = ""

    # HuggingFace settings
    hf_token: str = ""

    # Search settings
    max_results_per_source: int = 10
    min_images_per_dataset: int = 100


@dataclass
class DataMergerSettings:
    """Data merger configuration."""

    max_synthetic_ratio: float = 0.3  # 30% max synthetic
    train_split: float = 0.9  # 90% train, 10% val
    min_train_images: int = 100


# Default configurations
DEFAULT_COMFYUI_SETTINGS = ComfyUISettings()
DEFAULT_DISCOVERY_SETTINGS = DataDiscoverySettings()
DEFAULT_MERGER_SETTINGS = DataMergerSettings()
