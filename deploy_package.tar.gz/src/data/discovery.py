"""
Dataset Discovery Module - Search and download datasets from multiple sources.

Supported sources:
- Roboflow: 250K+ datasets
- Kaggle: 100K+ datasets
- HuggingFace: 10K+ vision datasets

References:
- Roboflow API: https://docs.roboflow.com/api-reference/datasets-and-projects
- Kaggle API: https://github.com/Kaggle/kaggle-api
- HuggingFace: https://huggingface.co/docs/hub/datasets-api
"""

from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import os
import re

# Optional imports - installed when needed
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

try:
    from kaggle.api.kaggle_api_extended import KaggleApi
    KAGGLE_AVAILABLE = True
except ImportError:
    KAGGLE_AVAILABLE = False

try:
    from datasets import load_dataset
    DATASETS_AVAILABLE = True
except ImportError:
    DATASETS_AVAILABLE = False

import shutil
import zipfile


@dataclass
class DatasetInfo:
    """Dataset information container."""
    source: str
    name: str
    url: str
    license: str
    annotations: str
    images: int
    categories: List[str]
    relevance_score: float = 0.0
    local_path: Optional[Path] = None


class DatasetDiscovery:
    """Dataset discovery from multiple sources."""

    def __init__(self, output_dir: Path = None):
        self.output_dir = Path(output_dir or "./data/discovered")
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def search(
        self,
        query: str,
        max_results: int = 10,
    ) -> List[DatasetInfo]:
        """
        Search for datasets across all sources.

        Args:
            query: Search query
            max_results: Maximum number of results per source

        Returns:
            List of dataset information
        """
        results = []

        # Search Roboflow
        results.extend(self._search_roboflow(query, max_results))

        # Search Kaggle
        results.extend(self._search_kaggle(query, max_results))

        # Search HuggingFace
        results.extend(self._search_huggingface(query, max_results))

        # Sort by relevance
        results.sort(key=lambda x: x.relevance_score, reverse=True)

        return results[:max_results]

    def _search_roboflow(self, query: str, max_results: int) -> List[DatasetInfo]:
        """
        Search Roboflow datasets via API.

        Reference: https://docs.roboflow.com/api-reference/datasets-and-projects
        """
        results = []
        api_key = os.getenv("ROBOFLOW_API_KEY")

        if not api_key:
            return results

        try:
            # Search datasets via Roboflow API
            url = f"https://api.roboflow.com/datasets?api_key={api_key}&name={query}&pages=1"
            response = requests.get(url, timeout=30)

            if response.status_code == 200:
                data = response.json()
                for item in data.get("datasets", [])[:max_results]:
                    # Calculate relevance score based on query match
                    score = self._calculate_relevance(query, item.get("name", ""))

                    results.append(DatasetInfo(
                        source="roboflow",
                        name=item.get("name", ""),
                        url=item.get("url", ""),
                        license=item.get("license", "unknown"),
                        annotations=item.get("annotation", "unknown"),
                        images=item.get("images", 0),
                        categories=item.get("classes", []),
                        relevance_score=score,
                    ))
        except Exception as e:
            # Log error but don't fail the whole search
            print(f"Roboflow search error: {e}")

        return results

    def _search_kaggle(self, query: str, max_results: int) -> List[DatasetInfo]:
        """
        Search Kaggle datasets via API.

        Reference: https://github.com/Kaggle/kaggle-api
        """
        results = []

        if not KAGGLE_AVAILABLE:
            return results

        try:
            # Initialize Kaggle API
            api = KaggleApi()
            api.authenticate()

            # Search datasets
            datasets = api.dataset_list(
                search=query,
                sort_by="hottest",
                page=1,
                page_size=max_results,
            )

            for ds in datasets:
                # Calculate relevance score
                title = ds.title or ""
                subtitle = ds.subtitle or ""
                score = self._calculate_relevance(query, f"{title} {subtitle}")

                # Extract categories from tags
                categories = [tag.name for tag in ds.tags] if ds.tags else []

                results.append(DatasetInfo(
                    source="kaggle",
                    name=ds.ref,
                    url=f"https://www.kaggle.com/datasets/{ds.ref}",
                    license=ds.license or "unknown",
                    annotations="coco" if "coco" in (subtitle or "").lower() else "unknown",
                    images=ds.size or 0,
                    categories=categories,
                    relevance_score=score,
                ))
        except Exception as e:
            # Log error but don't fail the whole search
            print(f"Kaggle search error: {e}")

        return results

    def _search_huggingface(self, query: str, max_results: int) -> List[DatasetInfo]:
        """
        Search HuggingFace datasets via API.

        Reference: https://huggingface.co/docs/hub/datasets-api
        """
        results = []

        if not DATASETS_AVAILABLE:
            return results

        try:
            from huggingface_hub import list_datasets

            # Search datasets
            datasets = list_datasets(
                search=query,
                limit=max_results,
            )

            for ds in datasets:
                # Calculate relevance score
                score = self._calculate_relevance(query, ds.id or "")

                # Get dataset info
                try:
                    info = ds.card_data or {}
                    annotations = info.get("annotations", {})
                    categories = info.get("categories", [])
                except:
                    annotations = {}
                    categories = []

                results.append(DatasetInfo(
                    source="huggingface",
                    name=ds.id,
                    url=f"https://huggingface.co/datasets/{ds.id}",
                    license=info.get("license", "unknown"),
                    annotations=annotations.get("task", "unknown"),
                    images=info.get("num_rows", 0),
                    categories=categories if isinstance(categories, list) else [],
                    relevance_score=score,
                ))
        except Exception as e:
            # Log error but don't fail the whole search
            print(f"HuggingFace search error: {e}")

        return results

    def _calculate_relevance(self, query: str, text: str) -> float:
        """
        Calculate relevance score between query and text.

        Uses TF-IDF like scoring: exact match > partial match > related terms

        Args:
            query: Search query
            text: Text to score against

        Returns:
            Relevance score 0.0 to 1.0
        """
        if not query or not text:
            return 0.0

        query_lower = query.lower()
        text_lower = text.lower()

        # Exact match
        if query_lower == text_lower:
            return 1.0

        # Query contained in text
        if query_lower in text_lower:
            return 0.9

        # Text contained in query
        if text_lower in query_lower:
            return 0.8

        # Word-level matching
        query_words = set(re.findall(r'\w+', query_lower))
        text_words = set(re.findall(r'\w+', text_lower))

        if not query_words or not text_words:
            return 0.0

        # Jaccard similarity
        intersection = query_words & text_words
        union = query_words | text_words

        jaccard = len(intersection) / len(union) if union else 0.0

        # Boost for matches at word boundaries
        for word in intersection:
            if text_lower.startswith(word) or text_lower.endswith(word):
                jaccard += 0.1

        return min(1.0, jaccard)

    def download(
        self,
        dataset_info: DatasetInfo,
        output_path: Path = None,
    ) -> Path:
        """
        Download dataset from source.

        Args:
            dataset_info: Dataset information
            output_path: Output path

        Returns:
            Path to downloaded dataset
        """
        output_path = Path(output_path or self.output_dir / dataset_info.name)
        output_path.mkdir(parents=True, exist_ok=True)

        # Route to appropriate download method based on source
        if dataset_info.source == "roboflow":
            self._download_roboflow(dataset_info, output_path)
        elif dataset_info.source == "kaggle":
            self._download_kaggle(dataset_info, output_path)
        elif dataset_info.source == "huggingface":
            self._download_huggingface(dataset_info, output_path)

        dataset_info.local_path = output_path
        return output_path

    def _download_roboflow(self, dataset_info: DatasetInfo, output_path: Path) -> None:
        """
        Download dataset from Roboflow.

        Reference: https://docs.roboflow.com/api-reference/datasets-and-projects
        """
        api_key = os.getenv("ROBOFLOW_API_KEY")
        if not api_key:
            raise ValueError("ROBOFLOW_API_KEY not set")

        # Roboflow uses workspace/project format
        # Extract project name from the dataset reference
        project = dataset_info.name.split("/")[-1] if "/" in dataset_info.name else dataset_info.name

        try:
            # Download via Roboflow API
            url = f"https://api.roboflow.com/{dataset_info.name}"
            params = {
                "api_key": api_key,
                "format": "zip",
            }

            response = requests.get(url, params=params, timeout=300)
            if response.status_code == 200:
                zip_path = output_path / "dataset.zip"
                with open(zip_path, "wb") as f:
                    f.write(response.content)

                # Extract
                with zipfile.ZipFile(zip_path, "r") as zip_ref:
                    zip_ref.extractall(output_path)

                # Clean up zip
                zip_path.unlink()
        except Exception as e:
            raise RuntimeError(f"Failed to download from Roboflow: {e}")

    def _download_kaggle(self, dataset_info: DatasetInfo, output_path: Path) -> None:
        """
        Download dataset from Kaggle.

        Reference: https://github.com/Kaggle/kaggle-api
        """
        if not KAGGLE_AVAILABLE:
            raise ImportError("kaggle package not installed")

        try:
            api = KaggleApi()
            api.authenticate()

            # Download dataset
            api.dataset_download_files(
                dataset_info.name,
                path=str(output_path),
                unzip=True,
            )
        except Exception as e:
            raise RuntimeError(f"Failed to download from Kaggle: {e}")

    def _download_huggingface(self, dataset_info: DatasetInfo, output_path: Path) -> None:
        """
        Download dataset from HuggingFace.

        Reference: https://huggingface.co/docs/datasets/download
        """
        if not DATASETS_AVAILABLE:
            raise ImportError("datasets package not installed")

        try:
            # Load and download dataset
            ds = load_dataset(
                dataset_info.name,
                trust_remote_code=True,
                cache_dir=str(output_path / ".cache"),
            )

            # Save to output directory
            ds.save_to_disk(str(output_path))
        except Exception as e:
            raise RuntimeError(f"Failed to download from HuggingFace: {e}")


class DataMerger:
    """Merge discovered datasets with synthetic data."""

    def __init__(self, max_synthetic_ratio: float = 0.3):
        """
        Initialize data merger.

        Args:
            max_synthetic_ratio: Maximum synthetic data ratio (30%)
        """
        self.max_synthetic_ratio = max_synthetic_ratio

    def merge(
        self,
        discovered_datasets: List[Path],
        synthetic_dataset: Path = None,
        output_dir: Path = None,
    ) -> Dict[str, Any]:
        """
        Merge datasets while respecting synthetic ratio limit.

        Args:
            discovered_datasets: List of discovered dataset paths
            synthetic_dataset: Synthetic dataset path
            output_dir: Output directory

        Returns:
            Merge result with statistics
        """
        output_dir = Path(output_dir or "./data/merged")
        output_dir.mkdir(parents=True, exist_ok=True)

        # Count real images
        real_images = 0
        for ds in discovered_datasets:
            real_images += self._count_images(ds / "train" if (ds / "train").exists() else ds)

        # Count synthetic images
        synthetic_images = 0
        if synthetic_dataset and synthetic_dataset.exists():
            synthetic_images = self._count_images(
                synthetic_dataset / "train" if (synthetic_dataset / "train").exists() else synthetic_dataset
            )

        # Calculate ratio and limit synthetic if needed
        total = real_images + synthetic_images
        if total > 0:
            synthetic_ratio = synthetic_images / total
        else:
            synthetic_ratio = 0

        # Limit synthetic data if ratio exceeded
        if synthetic_ratio > self.max_synthetic_ratio and real_images > 0:
            max_synthetic = int(real_images * self.max_synthetic_ratio / (1 - self.max_synthetic_ratio))
            synthetic_images = min(synthetic_images, max_synthetic)

        # Create merged structure
        merged_train = output_dir / "train" / "images"
        merged_val = output_dir / "val" / "images"
        merged_train.mkdir(parents=True, exist_ok=True)
        merged_val.mkdir(parents=True, exist_ok=True)

        # Copy real data
        for ds in discovered_datasets:
            self._copy_images(ds, merged_train, limit=None)

        # Copy limited synthetic data
        if synthetic_images > 0 and synthetic_dataset:
            self._copy_images(synthetic_dataset, merged_train, limit=synthetic_images)

        # Create val split (10%)
        val_count = int((real_images + synthetic_images) * 0.1)
        train_images = list(merged_train.glob("*"))
        for img in train_images[:val_count]:
            dst = merged_val / img.name
            shutil.move(str(img), str(dst))

        return {
            "train_images": len(list(merged_train.glob("*"))),
            "val_images": len(list(merged_val.glob("*"))),
            "synthetic_images": synthetic_images,
            "synthetic_ratio": synthetic_images / (real_images + synthetic_images) if (real_images + synthetic_images) > 0 else 0,
            "output_path": str(output_dir),
        }

    def _count_images(self, img_dir: Path) -> int:
        """Count images in directory."""
        if not img_dir.exists():
            return 0
        extensions = {".jpg", ".jpeg", ".png", ".bmp"}
        return len([f for f in img_dir.iterdir() if f.suffix.lower() in extensions])

    def _copy_images(self, src_dir: Path, dst_dir: Path, limit: int = None):
        """Copy images from source to destination."""
        if not src_dir.exists():
            return

        images = []
        for ext in [".jpg", ".jpeg", ".png", ".bmp"]:
            images.extend(list(src_dir.rglob(f"*{ext}")))

        if limit:
            images = images[:limit]

        for img in images:
            dst = dst_dir / img.name
            if not dst.exists():
                shutil.copy2(img, dst)
