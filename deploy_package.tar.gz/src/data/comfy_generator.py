"""
ComfyUI Workflow Generator - Generate synthetic data using ComfyUI.

Based on ComfyUI Agent API:
- https://docs.comfyui.ai/api/
- Local API at http://localhost:8188

This module integrates with local ComfyUI to generate synthetic training data.
"""

from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import asyncio
import aiohttp
import json
import uuid

from .config import ComfyUISettings


@dataclass
class WorkflowResult:
    """Workflow execution result."""
    status: str
    prompt_id: Optional[str] = None
    images: Optional[List[str]] = None
    error: Optional[str] = None


class ComfyUIClient:
    """ComfyUI API client for workflow execution."""

    def __init__(self, host: str = "localhost:8188", timeout: int = 300):
        self.host = host
        self.base_url = f"http://{host}"
        self.timeout = aiohttp.ClientTimeout(total=timeout)

    async def get_object_info(self) -> Dict:
        """Get all available node types."""
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.base_url}/object_info") as resp:
                return await resp.json()

    async def execute_workflow(self, workflow: Dict) -> str:
        """
        Execute a workflow.

        Args:
            workflow: Workflow JSON

        Returns:
            prompt_id
        """
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            payload = {"prompt": workflow}

            async with session.post(
                f"{self.base_url}/prompt",
                json=payload
            ) as resp:
                result = await resp.json()

                if "error" in result:
                    raise RuntimeError(f"Workflow error: {result['error']}")

                return result["prompt_id"]

    async def wait_for_completion(
        self,
        prompt_id: str,
        poll_interval: int = 2
    ) -> Dict:
        """Wait for workflow completion."""
        async with aiohttp.ClientSession() as session:
            while True:
                async with session.get(
                    f"{self.base_url}/history/{prompt_id}"
                ) as resp:
                    data = await resp.json()

                    if prompt_id in data:
                        status = data[prompt_id].get("status", {})

                        if status.get("completed"):
                            return data[prompt_id]

                        if status.get("errored"):
                            raise RuntimeError(
                                f"Execution failed: {status.get('error_msg', 'Unknown error')}"
                            )

                await asyncio.sleep(poll_interval)

    async def get_output_images(self, prompt_id: str) -> List[str]:
        """Get output images from completed workflow."""
        result = await self.wait_for_completion(prompt_id)
        outputs = result.get("outputs", {})

        images = []
        for node_id, node_data in outputs.items():
            if "images" in node_data:
                for img in node_data["images"]:
                    images.append(img["filename"])

        return images


class TaskClassifier:
    """Classify task type from description."""

    TASK_KEYWORDS = {
        "person": ["person", "human", "face", "people", "portrait", "man", "woman"],
        "object": ["object", "car", "dog", "cat", "item", "product", "thing"],
        "scene": ["scene", "building", "street", "landscape", "room", "environment"],
        "industrial": ["industrial", "manufacturing", "defect", "product", "part", "factory"],
        "medical": ["medical", "xray", "ct", "disease", "health", "patient"],
    }

    def classify(self, description: str) -> str:
        """Classify task type from description."""
        text = description.lower()

        for task_type, keywords in self.TASK_KEYWORDS.items():
            if any(kw in text for kw in keywords):
                return task_type

        return "object"  # Default


class WorkflowBuilder:
    """Build ComfyUI workflows for synthetic data generation."""

    def __init__(self):
        self.classifier = TaskClassifier()

    def build_text_to_image(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 1024,
        height: int = 1024,
        steps: int = 20,
        cfg: float = 7.0,
        sampler: str = "euler_ancestral",
        seed: int = None,
    ) -> Dict:
        """
        Build a text-to-image workflow.

        Args:
            prompt: Positive prompt
            negative_prompt: Negative prompt
            width: Image width
            height: Image height
            steps: Sampling steps
            cfg: CFG scale
            sampler: Sampler name
            seed: Random seed

        Returns:
            Workflow JSON
        """
        workflow = {}
        node_id = 1

        # 1. Checkpoint Loader
        workflow[str(node_id)] = {
            "class_type": "CheckpointLoaderSimple",
            "inputs": {"ckpt_name": "sd_xl_base_1.0.safetensors"}
        }
        checkpoint_id = str(node_id)
        node_id += 1

        # 2. Positive Prompt
        workflow[str(node_id)] = {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": prompt, "clip": [checkpoint_id, 1]}
        }
        positive_id = str(node_id)
        node_id += 1

        # 3. Negative Prompt
        neg_prompt = negative_prompt or "blurry, low quality, distorted, ugly, bad anatomy"
        workflow[str(node_id)] = {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": neg_prompt, "clip": [checkpoint_id, 1]}
        }
        negative_id = str(node_id)
        node_id += 1

        # 4. Empty Latent
        workflow[str(node_id)] = {
            "class_type": "EmptyLatentImage",
            "inputs": {
                "width": width,
                "height": height,
                "batch_size": 1
            }
        }
        latent_id = str(node_id)
        node_id += 1

        # 5. KSampler
        workflow[str(node_id)] = {
            "class_type": "KSampler",
            "inputs": {
                "model": [checkpoint_id, 0],
                "seed": seed or 42,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": sampler,
                "scheduler": "normal",
                "positive": [positive_id, 0],
                "negative": [negative_id, 0],
                "latent_image": [latent_id, 0]
            }
        }
        sampler_id = str(node_id)
        node_id += 1

        # 6. VAE Decode
        workflow[str(node_id)] = {
            "class_type": "VAEDecode",
            "inputs": {
                "samples": [sampler_id, 0],
                "vae": [checkpoint_id, 2]
            }
        }
        vae_id = str(node_id)
        node_id += 1

        # 7. Save Image
        workflow[str(node_id)] = {
            "class_type": "SaveImage",
            "inputs": {
                "images": [vae_id, 0],
                "filename_prefix": "synthetic"
            }
        }

        return workflow

    def build_for_task(
        self,
        task_description: str,
        class_prompts: Dict[str, str],
        **kwargs
    ) -> Dict:
        """
        Build workflow for specific task.

        Args:
            task_description: Task description
            class_prompts: Dict of class -> prompt
            **kwargs: Additional parameters

        Returns:
            Workflow JSON
        """
        task_type = self.classifier.classify(task_description)

        # Build workflow for first class
        first_class = list(class_prompts.keys())[0]
        prompt = class_prompts[first_class]

        return self.build_text_to_image(
            prompt=prompt,
            negative_prompt=f"blurry, low quality, distorted, {task_type}",
            **kwargs
        )


class ComfyUIGenerator:
    """Main generator class for synthetic data."""

    def __init__(
        self,
        comfy_host: str = "localhost:8188",
        output_dir: Path = None,
    ):
        self.client = ComfyUIClient(host=comfy_host)
        self.builder = WorkflowBuilder()
        self.output_dir = Path(output_dir or "./data/synthetic")
        self.output_dir.mkdir(parents=True, exist_ok=True)

    async def generate(
        self,
        prompts: List[str],
        negative_prompt: str = "",
        num_images: int = 10,
        width: int = 1024,
        height: int = 1024,
        steps: int = 20,
        cfg: float = 7.0,
    ) -> WorkflowResult:
        """
        Generate synthetic images.

        Args:
            prompts: List of prompts
            negative_prompt: Negative prompt
            num_images: Number of images to generate
            width: Image width
            height: Image height
            steps: Sampling steps
            cfg: CFG scale

        Returns:
            WorkflowResult with generated images
        """
        all_images = []

        try:
            for i, prompt in enumerate(prompts[:num_images]):
                # Build workflow
                workflow = self.builder.build_text_to_image(
                    prompt=prompt,
                    negative_prompt=negative_prompt,
                    width=width,
                    height=height,
                    steps=steps,
                    cfg=cfg,
                    seed=42 + i,
                )

                # Execute
                prompt_id = await self.client.execute_workflow(workflow)

                # Wait for completion
                images = await self.client.get_output_images(prompt_id)
                all_images.extend(images)

            return WorkflowResult(
                status="completed",
                images=all_images,
            )

        except Exception as e:
            return WorkflowResult(
                status="failed",
                error=str(e),
            )

    async def generate_for_classes(
        self,
        class_prompts: Dict[str, str],
        num_per_class: int = 10,
        **kwargs
    ) -> Dict[str, List[str]]:
        """
        Generate images for multiple classes.

        Args:
            class_prompts: Dict of class -> prompt
            num_per_class: Images per class
            **kwargs: Additional parameters

        Returns:
            Dict of class -> list of image filenames
        """
        results = {}

        for class_name, prompt in class_prompts.items():
            result = await self.generate(
                prompts=[prompt] * num_per_class,
                negative_prompt=f"blurry, low quality, distorted, {class_name}",
                **kwargs
            )

            results[class_name] = result.images if result.images else []

        return results


class ComfyUISyncWrapper:
    """Synchronous wrapper for ComfyUI generator."""

    def __init__(self, **kwargs):
        self.generator = ComfyUIGenerator(**kwargs)

    def generate(self, *args, **kwargs):
        """Synchronous generate."""
        return asyncio.run(self.generator.generate(*args, **kwargs))

    def generate_for_classes(self, *args, **kwargs):
        """Synchronous generate for classes."""
        return asyncio.run(self.generator.generate_for_classes(*args, **kwargs))


# Predefined workflows
PREDEFINED_WORKFLOWS = {
    "txt2img": WorkflowBuilder().build_text_to_image,
}


# Default prompts for common object detection tasks
DEFAULT_PROMPTS = {
    "defect": "A clear photo of {class_name} defect, high quality, detailed",
    "normal": "A clear photo of normal {class_name}, high quality, detailed",
    "object": "A {class_name} on a clean background, professional photography",
}
